public interface ITicker
{
    public void Tick();
}
