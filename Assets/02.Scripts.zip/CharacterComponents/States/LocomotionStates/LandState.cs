using UnityEngine;

public class LandState : CharacterState
{
    const int LandFreeze = 6; // ���� ���� ������

    public LandState(CharacterFSM f) : base(f) { }
    public override CharacterStateTag? StateTag => CharacterStateTag.Idle;

    protected override void OnEnter()
    {
        property.isInputEnabled = true;
        phys.SetPose(CharacterStateTag.Idle);
        Play(property.characterName + "/" + animCfg.GetClipKey(AnimKey.Land));
    }

    protected override void OnTick()
    {
        if (TryStartSkill()) return;

        if (ElapsedFrames >= LandFreeze) Transition("Idle");
    }

    protected override void OnExit() { }
}
