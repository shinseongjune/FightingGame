public interface IInputProvider
{
    InputData GetSnapshot();
}