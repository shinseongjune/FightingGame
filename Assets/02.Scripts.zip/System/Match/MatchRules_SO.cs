using UnityEngine;
[CreateAssetMenu(fileName = "MatchRules", menuName = "SO/Match Rules Preset")]
public class MatchRules_SO : ScriptableObject
{
    public MatchRulesData data = MatchRulesData.Default;
}